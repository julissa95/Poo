﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Personna
{
    class Program
    {
        static void Main(string[] args)
        {


            ListaAlumnos alumnos = new ListaAlumnos();


            ConsoleKeyInfo op;
            do
            {
                Console.Clear(); //Limpiar la pantalla
                Console.Write("[A]Agregar nuevo alumno");
                Console.Write("[B]Guardar en archivo  serializacion ");
                Console.Write("[C]Recuperar Datos deserializacion ");
                Console.Write("[D] Listar, El Metodo Mostrar");
                Console.Write("[Esc]Salirtnn");
                Console.WriteLine("Seleccione opcion...");
                op = Console.ReadKey(true);//Que no muestre la tecla señalada

                //métodos son acciones, las propiedades son valores
                switch (op.Key)
                {
                    case ConsoleKey.A:
                        Console.WriteLine("Ud seleccionó la opción Agregar");
                        alumnos.listAlumno.Add(new Alumno("Strajch", "Rosso", 1234506789, 9876054321, 55));
                        Console.Write("Presione una tecla para continuar...");
                        Console.ReadKey();
                        break;

                    case ConsoleKey.B:
                        Console.WriteLine("Ud seleccionó la opción serializacion");
                        SpecialCharacters specialCharacters = new SpecialCharacters { Umlaute = "äüö" };

                        // serialize object to xml 

                        MemoryStream memoryStreamSerialize = new MemoryStream();
                        XmlSerializer xmlSerializerSerialize = new XmlSerializer(typeof(SpecialCharacters));
                        XmlTextWriter xmlTextWriterSerialize = new XmlTextWriter(memoryStreamSerialize, Encoding.UTF8);

                        xmlSerializerSerialize.Serialize(xmlTextWriterSerialize, specialCharacters);
                        memoryStreamSerialize = (MemoryStream)xmlTextWriterSerialize.BaseStream;

                        // converts a byte array of unicode values (UTF-8 enabled) to a string 
                        UTF8Encoding encodingSerialize = new UTF8Encoding();
                        string serializedXml = encodingSerialize.GetString(memoryStreamSerialize.ToArray());

                        try
                        {
                            xmlTextWriterSerialize.Close();
                            memoryStreamSerialize.Close();
                            memoryStreamSerialize.Dispose();
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("{0}  Error, Try Again.", e);
                        }

                        Console.Write("Presione una tecla para continuar...");
                        Console.ReadKey();
                        break;

                    case ConsoleKey.C:
                        //Console.WriteLine("Ud seleccionó la opción deserializacion");
                        //UTF8Encoding encodingDeserialize = new UTF8Encoding();
                        //byte[] byteArray = encodingDeserialize.GetBytes (serializedXml);

                        //using (MemoryStream memoryStreamDeserialize = new MemoryStream(byteArray))
                        //{
                        //    XmlSerializer xmlSerializerDeserialize = new XmlSerializer(typeof(SpecialCharacters));
                        //    XmlTextWriter xmlTextWriterDeserialize = new XmlTextWriter(memoryStreamDeserialize, Encoding.UTF8);

                        //    try
                        //    {
                        //        SpecialCharacters deserializedObject = (SpecialCharacters)xmlSerializerDeserialize.Deserialize(xmlTextWriterDeserialize.BaseStream);
                        //    }
                        //    catch (Exception e)
                        //    {
                        //        Console.WriteLine("{0}  Error, Try Again.", e);
                        //    }

                        //}
                        //Console.Write("Presione una tecla para continuar...");
                        //Console.ReadKey();
                        break;

                    case ConsoleKey.D:
                        Console.WriteLine("Ud seleccionó la opción MonstrarDatos");
                 
                         foreach (var alum in alumnos.listAlumno)
                        {
                            alum.mostrar();
                        }

                        Console.Write("Presione una tecla para continuar...");
                        Console.ReadKey();
                        break;

                    case ConsoleKey.Escape:
                        Console.WriteLine("Chao");

                        break;
                }
            } while (op.Key != ConsoleKey.Escape);

            Console.ReadKey();





            //listaAlumnos.Add(new Alumno { nombre1 = "Strajch", apellido1 = "Rosso", dni1 = 1234506789, legajo1 = 9876054321, notaFinal1 = 55 });
            //listaAlumnos.Add(new Alumno { nombre1 = "Beeto", apellido1 = "Saito", dni1 = 9876504321, legajo1 = 1234506789, notaFinal1 = 43 });
            //listaAlumnos.Add(new Alumno { nombre1 = "Marmori", apellido1 = "Nora", dni1 = 20110520, legajo1 = 654321987, notaFinal1 = 84 });

            //System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(listaAlumnos.GetType());

            //try
            //{
            //    x.Serialize(Console.Out, listaAlumnos);
            //    Console.WriteLine();
            //    Console.ReadLine(); -
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine("{0}  Error, Try Again.", e);
            //}



            //            SpecialCharacters specialCharacters = new SpecialCharacters { Umlaute = "äüö" };

            //// serialize object to xml 

            //MemoryStream memoryStreamSerialize = new MemoryStream();
            //XmlSerializer xmlSerializerSerialize = new XmlSerializer(typeof(SpecialCharacters));
            //XmlTextWriter xmlTextWriterSerialize = new XmlTextWriter(memoryStreamSerialize, Encoding.UTF8);

            //xmlSerializerSerialize.Serialize(xmlTextWriterSerialize, specialCharacters);
            //memoryStreamSerialize = (MemoryStream)xmlTextWriterSerialize.BaseStream;

            //// converts a byte array of unicode values (UTF-8 enabled) to a string 
            //UTF8Encoding encodingSerialize = new UTF8Encoding();
            //string serializedXml = encodingSerialize.GetString(memoryStreamSerialize.ToArray());

            //try
            //{
            //    xmlTextWriterSerialize.Close();
            //    memoryStreamSerialize.Close();
            //    memoryStreamSerialize.Dispose();
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine("{0}  Error, Try Again.", e);
            //}

            // deserialize xml to object 

            // converts a string to a UTF-8 byte array. 
            //            UTF8Encoding encodingDeserialize = new UTF8Encoding();
            //byte[] byteArray = encodingDeserialize.GetBytes(serializedXml);

            //using (MemoryStream memoryStreamDeserialize = new MemoryStream(byteArray))
            //{
            //    XmlSerializer xmlSerializerDeserialize = new XmlSerializer(typeof(SpecialCharacters));
            //    XmlTextWriter xmlTextWriterDeserialize = new XmlTextWriter(memoryStreamDeserialize, Encoding.UTF8);

            //    try
            //    {
            //        SpecialCharacters deserializedObject = (SpecialCharacters)xmlSerializerDeserialize.Deserialize(xmlTextWriterDeserialize.BaseStream);
            //    }
            //    catch (Exception e)
            //    {
            //        Console.WriteLine("{0}  Error, Try Again.", e);
            //    }

            //}

        }
        [Serializable]
        public class SpecialCharacters
        {
            public string Umlaute { get; set; }
        }







    }
}
        
        
    

