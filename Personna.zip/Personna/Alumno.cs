﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personna
{
   public class Alumno : Persona
    {
        private long legajo;
        private float notaFinal;

        public long legajo1 { get; set; }
        public float notaFinal1 { get; set; }

        public Alumno(string nombre, string apellido, long dni, long legajo, float notaFinal) : base(apellido, nombre, dni)
        {
            legajo = legajo1;
            notaFinal = notaFinal1;
        }
       
        
        public override void mostrar()
        {
            Console.WriteLine("....... "+legajo);
            Console.WriteLine("....... " + notaFinal);
        }


    }
}
