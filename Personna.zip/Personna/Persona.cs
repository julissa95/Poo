﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personna
{
   public class Persona
    {
        private string nombre;
        private string apellido;
        private long dni;

        public Persona(string nombre, string apellido)
        {
            nombre = nombre1;
            apellido = apellido1;
        }

        public Persona(string nombre, string apellido, long dni)
        {
            nombre = nombre1;
            apellido = apellido1;
            dni = dni1;
        }
        
        public string nombre1 { get; set; }
        public string apellido1 { get; set; }
        public long dni1 { get; set; }

        public virtual void mostrar ()
        {
            Console.WriteLine("Los datos son: " + nombre1);
                Console.WriteLine("Los datos son: " + apellido);
                Console.WriteLine("Los datos son: " + dni);

        }
        //public virtual void mostrar();



    }
}


